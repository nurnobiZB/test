<?php
session_start();
$config = require __DIR__ . '/../config.php';
if (isset($_GET['logout'])) { session_destroy(); header('Location: index.php'); exit; }
if (!isset($_SESSION['admin'])) {
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        if (hash_equals($config['admin_password'], $_POST['password'] ?? '')) {
            $_SESSION['admin']=true; header('Location: index.php'); exit;
        }
        $error='ভুল পাসওয়ার্ড।';
    }
    ?>
    <!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title><link rel="stylesheet" href="../assets/style.css"></head>
    <body><div class="wrap"><div class="card small"><h2>🔐 Zinnat Location Admin</h2>
    <?php if(isset($error)) echo '<div class="status">'.$error.'</div>'; ?>
    <form method="post"><label>Admin Password</label><input type="password" name="password" required><button>Login</button></form>
    </div></div></body></html><?php exit;
}
try {
 $pdo=new PDO("mysql:host={$config['db']['host']};dbname={$config['db']['name']};charset=utf8mb4",$config['db']['user'],$config['db']['pass'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
 $rows=$pdo->query("SELECT * FROM locations ORDER BY id DESC LIMIT 200")->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){ $rows=[]; $error='Database connection failed.'; }
?>
<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Location Admin</title><link rel="stylesheet" href="../assets/style.css"></head>
<body><div class="wrap wide"><div class="card"><div class="top"><div><h1>📍 Customer Locations</h1><p>Zinnat Broadband</p></div><a href="?logout=1">Logout</a></div>
<?php if(isset($error)) echo '<div class="status">'.$error.'</div>'; ?>
<div class="tablewrap"><table><tr><th>Name</th><th>Customer</th><th>Address</th><th>GPS</th><th>Accuracy</th><th>Time</th><th>Map</th></tr>
<?php foreach($rows as $r): ?><tr>
<td><?=htmlspecialchars($r['name'])?></td><td><?=htmlspecialchars($r['customer'])?></td>
<td><?=htmlspecialchars($r['address'] ?? '')?></td>
<td><?=htmlspecialchars($r['latitude'])?>, <?=htmlspecialchars($r['longitude'])?></td>
<td><?=htmlspecialchars($r['accuracy'])?> m</td><td><?=htmlspecialchars($r['created_at'])?></td>
<td><a target="_blank" href="<?=htmlspecialchars($r['maps_url'])?>">📍 Open</a></td>
</tr><?php endforeach; ?></table></div></div></div></body></html>

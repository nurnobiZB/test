CREATE DATABASE IF NOT EXISTS zinnat_location CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE zinnat_location;
CREATE TABLE IF NOT EXISTS locations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  customer VARCHAR(100) NOT NULL,
  latitude DECIMAL(10,7) NOT NULL,
  longitude DECIMAL(10,7) NOT NULL,
  accuracy DECIMAL(10,2) NULL,
  maps_url VARCHAR(500) NOT NULL,
  address VARCHAR(500) NULL,
  created_at DATETIME NOT NULL,
  ip_address VARCHAR(45) NULL,
  INDEX(customer),
  INDEX(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

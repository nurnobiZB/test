# Zinnat Broadband Customer Location Sharing

এই প্রজেক্টে কাস্টমার মোবাইল ব্রাউজার থেকে অনুমতি দিয়ে GPS location পাঠাতে পারে। Admin panel-এ জমা হওয়া location দেখা যায় এবং Google Maps-এ খোলা যায়।

## প্রয়োজন
- PHP 7.4+ / 8.x
- MySQL/MariaDB
- HTTPS enabled domain (GPS browser API-এর জন্য প্রয়োজন)
- PHP `pdo_mysql`
- Email-এর জন্য server-এর `mail()` configuration

## সেটআপ
1. `database.sql` MySQL-এ import করুন।
2. `config.php`-তে database user/password, admin password এবং email ঠিক করুন।
3. সব ফাইল hosting-এ upload করুন।
4. `https://your-domain.com/` কাস্টমারদের দিন।
5. `https://your-domain.com/admin/` থেকে admin login করুন।

## গুরুত্বপূর্ণ
- `CHANGE_THIS_ADMIN_PASSWORD` অবশ্যই শক্তিশালী password দিয়ে বদলাবেন।
- Production-এ HTTPS ব্যবহার করুন।
- GPS location কেবল customer permission দেওয়ার পর নেওয়া হয়।
- এই starter version-এ email PHP `mail()` ব্যবহার করছে। Hosting-এ mail disabled থাকলে SMTP/PHPMailer ব্যবহার করা উচিত।
- Google Maps link-এর জন্য API key প্রয়োজন নেই, কারণ এটি সাধারণ Maps query URL।
- GPS পাওয়ার পর server-side reverse geocoding দিয়ে readable address নেওয়া হয়, যেমন `Durakuti Bazar, Lalmonirhat` (যদি map database-এ সেই তথ্য পাওয়া যায়)। এই starter version-এ OpenStreetMap Nominatim ব্যবহার করা হয়েছে। Production-এ বেশি traffic হলে নিজের geocoder বা paid geocoding service ব্যবহার করুন এবং তাদের usage policy/rate limit মেনে চলুন।

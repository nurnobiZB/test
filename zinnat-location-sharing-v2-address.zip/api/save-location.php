<?php
header('Content-Type: application/json; charset=utf-8');
$config = require __DIR__ . '/../config.php';

function reverseGeocode($lat, $lng) {
    $url = 'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat='
         . rawurlencode($lat) . '&lon=' . rawurlencode($lng) . '&zoom=18&addressdetails=1&accept-language=bn,en';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_HTTPHEADER => ['User-Agent: ZinnatBroadband-Location/1.0 (contact@zinnatbroadband.net)'],
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    if (!$response) return '';
    $json = json_decode($response, true);
    return isset($json['display_name']) ? trim($json['display_name']) : '';
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    foreach (['name','customer','lat','lng'] as $k) {
        if (!isset($data[$k]) || $data[$k] === '') throw new Exception('Required field missing');
    }

    $lat = filter_var($data['lat'], FILTER_VALIDATE_FLOAT);
    $lng = filter_var($data['lng'], FILTER_VALIDATE_FLOAT);
    if ($lat === false || $lng === false || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
        throw new Exception('Invalid coordinates');
    }

    $pdo = new PDO(
        "mysql:host={$config['db']['host']};dbname={$config['db']['name']};charset=utf8mb4",
        $config['db']['user'], $config['db']['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $maps = $data['maps_url'] ?? "https://www.google.com/maps?q={$lat},{$lng}";
    $address = reverseGeocode($lat, $lng);
    $accuracy = isset($data['accuracy']) ? (float)$data['accuracy'] : null;

    $stmt = $pdo->prepare("INSERT INTO locations (name, customer, latitude, longitude, accuracy, maps_url, address, created_at, ip_address)
                           VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)");
    $stmt->execute([
        trim($data['name']), trim($data['customer']), $lat, $lng, $accuracy,
        $maps, $address, $_SERVER['REMOTE_ADDR'] ?? ''
    ]);

    $subject = "New Customer Location - {$config['site_name']}";
    $body = "New customer location received\n\n"
          . "Name: " . trim($data['name']) . "\n"
          . "Customer ID/Mobile: " . trim($data['customer']) . "\n"
          . "GPS: {$lat}, {$lng}\n"
          . "Address: " . ($address ?: 'Address not found') . "\n"
          . "Accuracy: " . ($accuracy !== null ? round($accuracy).' meters' : 'N/A') . "\n"
          . "Google Maps: {$maps}\n"
          . "Time: " . date('Y-m-d H:i:s') . "\n";
    $headers = "From: {$config['mail_from']}\r\n"
             . "Reply-To: {$config['mail_from']}\r\n"
             . "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($config['email_to'], $subject, $body, $headers);

    echo json_encode(['ok'=>true,'message'=>'আপনার লোকেশন সফলভাবে Zinnat Broadband-এ পাঠানো হয়েছে।']);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'message'=>'লোকেশন পাঠানো যায়নি। সার্ভার সেটিংস পরীক্ষা করুন।']);
}

<?php
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'zinnat_location',
        'user' => 'YOUR_DB_USER',
        'pass' => 'YOUR_DB_PASSWORD',
    ],
    'admin_password' => 'CHANGE_THIS_ADMIN_PASSWORD',
    'email_to' => 'info@zinnatbroadband.net',
    'mail_from' => 'noreply@zinnatbroadband.net',
    'site_name' => 'Zinnat Broadband',
    // Reverse geocoding uses OpenStreetMap Nominatim. Server must allow outbound HTTPS requests.

];

<?php
$config = require __DIR__ . '/config.php';
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Zinnat Broadband - Location Share</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="brand"><div class="logo">ZB</div><div><h1>Zinnat Broadband</h1><p>Customer Location Sharing</p></div></div>
    <form id="locationForm">
      <label>Customer Name</label>
      <input id="name" required placeholder="আপনার নাম">
      <label>Customer ID / Mobile</label>
      <input id="customer" required placeholder="Customer ID বা মোবাইল নম্বর">
      <button type="button" id="locBtn">📍 আমার বর্তমান লোকেশন নিন</button>
      <div id="status" class="status">লোকেশন নেওয়ার জন্য উপরের বাটনে চাপুন।</div>
      <div id="result" class="result hidden">
        <b>আপনার লোকেশন</b>
        <div id="address">লোড হচ্ছে...</div>
        <small id="coords"></small>
        <div class="actions">
          <button type="button" id="copyBtn" class="secondary">📋 লোকেশন কপি</button>
          <button type="submit">📤 Zinnat-এ পাঠান</button>
        </div>
      </div>
    </form>
    <p class="privacy">লোকেশন শুধু আপনার অনুমতির পর নেওয়া হবে এবং Zinnat Broadband-এ সংযোগ/সাপোর্টের কাজে ব্যবহার করা হবে।</p>
  </div>
</div>
<script>
let geo = null, address = '';
const statusEl = document.getElementById('status');
const result = document.getElementById('result');

document.getElementById('locBtn').onclick = () => {
  if (!navigator.geolocation) {
    statusEl.textContent = 'এই ডিভাইসে GPS/Location সাপোর্ট নেই।';
    return;
  }
  statusEl.textContent = 'লোকেশন নেওয়া হচ্ছে... GPS চালু রাখুন।';
  navigator.geolocation.getCurrentPosition(async p => {
    geo = {lat:p.coords.latitude, lng:p.coords.longitude, accuracy:p.coords.accuracy};
    document.getElementById('coords').textContent =
      `GPS: ${geo.lat.toFixed(6)}, ${geo.lng.toFixed(6)} | Accuracy: ${Math.round(geo.accuracy)}m`;
    address = `https://www.google.com/maps?q=${geo.lat},${geo.lng}`;
    document.getElementById('address').innerHTML =
      `<a target="_blank" rel="noopener" href="${address}">📍 Google Maps-এ লোকেশন দেখুন</a>`;
    result.classList.remove('hidden');
    statusEl.textContent = 'লোকেশন পাওয়া গেছে। এখন Zinnat Broadband-এ পাঠাতে পারেন।';
  }, e => {
    statusEl.textContent = 'লোকেশন পাওয়া যায়নি: ' + (e.message || 'Permission দিন এবং GPS চালু করুন।');
  }, {enableHighAccuracy:true, timeout:15000, maximumAge:0});
};

document.getElementById('copyBtn').onclick = async () => {
  if (!geo) return;
  const text = `Zinnat Broadband Location\n${address}\nGPS: ${geo.lat}, ${geo.lng}`;
  await navigator.clipboard.writeText(text);
  statusEl.textContent = 'লোকেশন কপি হয়েছে।';
};

document.getElementById('locationForm').onsubmit = async e => {
  e.preventDefault();
  if (!geo) { statusEl.textContent = 'আগে আপনার লোকেশন নিন।'; return; }
  statusEl.textContent = 'পাঠানো হচ্ছে...';
  const payload = {
    name: document.getElementById('name').value.trim(),
    customer: document.getElementById('customer').value.trim(),
    lat: geo.lat, lng: geo.lng, accuracy: geo.accuracy,
    maps_url: address
  };
  try {
    const r = await fetch('api/save-location.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify(payload)
    });
    const j = await r.json();
    statusEl.textContent = j.message || (j.ok ? 'লোকেশন পাঠানো হয়েছে।' : 'সমস্যা হয়েছে।');
    if (j.ok) e.target.reset();
  } catch(err) {
    statusEl.textContent = 'সার্ভারে পাঠানো যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করুন।';
  }
};
</script>
</body>
</html>
